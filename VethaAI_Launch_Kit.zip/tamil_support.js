This is a placeholder for tamil_support.js
