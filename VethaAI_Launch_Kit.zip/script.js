This is a placeholder for script.js
